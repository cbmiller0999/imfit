## Functions_objects_1d Directory

This directory contains source code for 1D surface-brightness-profile function objects, for use in profilefit
(the undocumented, unsupported profile-fitting variant of Imfit).
