## Function_objects Directory

This directory contains class files for implementing 2D image functions (include image functions
that use 3D line-of-sight integration). It includes all the standard image functions included in
the public releases of Imfit, along with some extra experimental and testing functions.

Also included is code for assisting in 3D line-of-sight integration.
