## Profile_data Directory

This directory contains 1D surface-brightness profiles for use in regression tests
for profilefit.

This is *not* a standard part of Imfit.

(Data originally published in Trujillo et al. 2004.)
