## solvers

This directory contains code for the various different "solvers" (minimization algorithms)
used by Imfit.
