Imfit Design and API
====================

.. toctree::
   :maxdepth: 2
   :caption: DESIGN

   design-and-architecture

.. toctree::
   :maxdepth: 2
   :caption: CLASSES

   model_object
   function_object
   convolver
   oversampled_region
   psf_oversampling_info

.. toctree::
   :maxdepth: 2
   :caption: FILES

   getimages
   image_io
