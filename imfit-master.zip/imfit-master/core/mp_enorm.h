/* Header file for enorm function */

#ifndef _MP_ENORM_H_
#define _MP_ENORM_H_

double mp_enorm( int n, const double *x );


#endif /* _MP_ENORM_H_ */
