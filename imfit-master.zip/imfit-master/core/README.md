## Core Source-code Directory

This directory contains C++ code used by imfit, imfit-mcmc, and makeimage which is not 
concerned with solvers/minimizers (see "solvers" directory) or code for individual 
function objects.
