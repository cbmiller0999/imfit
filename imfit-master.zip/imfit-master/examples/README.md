## Examples Directory

This directory contains example files (FITS images and configuration text files) for use with Imfit.
It is included with all distributions, including the minimal pre-compiled binary distributions.

See README_examples.txt for details on using these files.
