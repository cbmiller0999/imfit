## Profile_fitting Directory

This directory contains code for profilefit, an unsupported (& undocumented) variant of imfit
for performing fits to 1D surface-brightness profiles.

This is *not* a standard part of Imfit.
